package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;



public class CodeGeneratorActivity extends AppCompatActivity {

    //Sets up all the variables
    private Button returnButton;
    private TextView etNumbers;
    private String randomNum;
    private FirebaseFirestore dataBase = FirebaseFirestore.getInstance();
    private Map<String, Object> userInfo = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_generator);

        //Receives the username from MainActivity
        Intent intent = getIntent();
        final String username = intent.getStringExtra(MainActivity.USER_NAME2);


        //Sets up all of the variables
        returnButton = findViewById(R.id.rtnBtn);
        etNumbers = findViewById(R.id.tvNumbers);
        randomNum = generateNumber(randomNum);

        //Puts all the information into a Map
        userInfo.put("username", username);
        userInfo.put("Code",randomNum);

        //Outputs the unique 6 digit Code for DuoMobile
        etNumbers.setText(randomNum);

        //Sets up the onClick for the returnButton
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Writes the map to the Firebase
                dataBase.collection("codes").document(username).set(userInfo);
                startActivity(new Intent(CodeGeneratorActivity.this, MainActivity.class));
            }
        });

    }

    //Function to create a random 6 digit number
    private String generateNumber(String word) {
        Random r = new Random();

        //Creates each individual unique number between 0 and 9
        String dig1 = Integer.toString((r.nextInt(9)));
        String dig2 = Integer.toString((r.nextInt(9)));
        String dig3 = Integer.toString((r.nextInt(9)));
        String dig4 = Integer.toString((r.nextInt(9)));
        String dig5 = Integer.toString((r.nextInt(9)));
        String dig6 = Integer.toString((r.nextInt(9)));


        return dig1 + dig2 + dig3 + dig4 + dig5 + dig6;
    }
}
