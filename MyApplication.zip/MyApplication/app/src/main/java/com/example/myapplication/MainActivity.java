package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import io.opencensus.tags.Tag;

public class MainActivity extends AppCompatActivity {

    //Sets up all the variables
    private Button registerButton;
    private Button generateButton;
    private static final String TAG = "MainActivity";
    public static final String USER_NAME2 = "com.example.myapplication.U_N";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Receives the username from RegisterActivity
        Intent intent = getIntent();
        final String username = intent.getStringExtra(RegisterActivity.USER_NAME);

        //Sets up all of the variables
        registerButton = findViewById(R.id.btnRegisterInitial);
        generateButton = findViewById(R.id.generateBtn);

        //Sets up the onCLick for the generateButton
        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Sends the username to the CodeGeneratorActivity (needs this for part of the Firebase)
                Intent intent = new Intent(MainActivity.this, CodeGeneratorActivity.class);
                intent.putExtra(USER_NAME2, username);
                startActivity(intent);
            }
        });

        //Sets up the onCLick for the registerButton
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);

            }
        });

    }
}

