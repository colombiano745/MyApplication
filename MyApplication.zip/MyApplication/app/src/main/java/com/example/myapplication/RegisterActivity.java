package com.example.myapplication;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import android.net.wifi.WifiManager;
import java.util.ArrayList;
import java.util.List;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.net.wifi.ScanResult;



public class RegisterActivity extends AppCompatActivity {


    //Sets up all the variables
    public static final String USER_NAME = "com.example.myapplication.USER_NAME";
    private Button registerButton;
    private EditText etUser, etPass, etFirst, etLast, etEmail;
    private FirebaseFirestore dataBase = FirebaseFirestore.getInstance();
    private Map<String, Object> userInfo = new HashMap<>();
    private static final String TAG = "Main2Activity";
    private String BSSID;
    private WifiManager wifiManager;
    private List<ScanResult> results;
    private ArrayList<String> arrayList = new ArrayList<>();
    private ArrayAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //Always requests permission in order to retrieve BSSID
        requestPermissions(new String[]{
                Manifest.permission.ACCESS_COARSE_LOCATION}, 1);

        //Sets up WifiManager to retrieve BSSID
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiManager.setWifiEnabled(true);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        BSSID = wifiInfo.getBSSID();



        //Sets up all of the variables
        etFirst = findViewById(R.id.etFirstName);
        etLast = findViewById(R.id.etLastName);
        etUser = findViewById(R.id.etOsuUserName);
        etPass = findViewById(R.id.etOsuPassword);
        etEmail = findViewById(R.id.etEmail);
        registerButton = findViewById(R.id.btnRegister);



        //Sets up the onClick for the registerButton
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //Retrieves all of the information typed in by the user
                String firstName = etFirst.getText().toString();
                String lastName = etLast.getText().toString();
                String username = etUser.getText().toString();
                String password = etPass.getText().toString();
                String email = etEmail.getText().toString();

                //Sends all the info to Firebase
                submitInfo(view, firstName,lastName,username,password,email,BSSID);

                //Retrieves the username that will be sent to the MainActivity
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                intent.putExtra(USER_NAME, username);
                startActivity(intent);

            }
        });
    }

    private void submitInfo(View view, String firstName, String lastName, String username, String password, String email, String BSSID){

        //Puts all the information into a Map
        userInfo.put("firstName", firstName);
        userInfo.put("lastName", lastName);
        userInfo.put("username", username);
        userInfo.put("password", password);
        userInfo.put("email", email);
        userInfo.put("BSSID", BSSID);

        //Writes the map to the Firebase
        dataBase.collection("users").document(username)
                .set(userInfo)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });


    }

}
